<div class="wrap">
    <div id="wpvite"></div>
</div>